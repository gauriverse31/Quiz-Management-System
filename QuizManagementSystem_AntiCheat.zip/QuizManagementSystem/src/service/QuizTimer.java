package service;

import javax.swing.*;
import java.awt.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

/**
 * ⏱️ Quiz Timer — runs on a background thread (Runnable + Thread).
 *
 * Design:
 *  - Uses Java's Thread + Runnable for true background countdown.
 *  - AtomicBoolean ensures thread-safe stop() calls.
 *  - SwingUtilities.invokeLater() safely updates Swing UI from non-EDT thread.
 *  - Callbacks: onTick (every second) and onExpire (when time runs out).
 *
 * Usage:
 *   QuizTimer timer = new QuizTimer(120, label, this::autoSubmit);
 *   timer.start();
 *   // later:
 *   timer.stop();
 */
public class QuizTimer implements Runnable {

    private final int totalSeconds;
    private int remainingSeconds;
    private final JLabel displayLabel;       // UI label to update
    private final Runnable onExpireCallback; // Called when timer hits 0
    private final AtomicBoolean running = new AtomicBoolean(false);
    private Thread timerThread;

    /**
     * @param totalSeconds    Total quiz duration in seconds (e.g. 120 for 2 min)
     * @param displayLabel    JLabel to update with countdown text
     * @param onExpireCallback Runnable to call when time is up
     */
    public QuizTimer(int totalSeconds, JLabel displayLabel, Runnable onExpireCallback) {
        this.totalSeconds    = totalSeconds;
        this.remainingSeconds = totalSeconds;
        this.displayLabel    = displayLabel;
        this.onExpireCallback = onExpireCallback;
    }

    /** Starts the timer on a new daemon thread. */
    public void start() {
        running.set(true);
        timerThread = new Thread(this, "QuizTimerThread");
        timerThread.setDaemon(true); // won't prevent JVM exit
        timerThread.start();
    }

    /** Stops the timer (e.g. when student submits early). */
    public void stop() {
        running.set(false);
        if (timerThread != null) timerThread.interrupt();
    }

    /** Returns elapsed seconds (total - remaining). */
    public int getElapsedSeconds() {
        return totalSeconds - remainingSeconds;
    }

    /**
     * Core Runnable logic — counts down every second.
     */
    @Override
    public void run() {
        while (running.get() && remainingSeconds >= 0) {
            final int secs = remainingSeconds;

            // ✅ Always update Swing UI from the Event Dispatch Thread (EDT)
            SwingUtilities.invokeLater(() -> updateLabel(secs));

            if (remainingSeconds == 0) {
                running.set(false);
                SwingUtilities.invokeLater(onExpireCallback);
                return;
            }

            try {
                Thread.sleep(1000); // wait 1 second
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return; // timer was stopped externally
            }

            remainingSeconds--;
        }
    }

    /** Formats seconds into MM:SS and updates the label with color coding. */
    private void updateLabel(int seconds) {
        int mins = seconds / 60;
        int secs = seconds % 60;
        String text = String.format("⏱  %02d:%02d", mins, secs);
        displayLabel.setText(text);

        // Color changes as time runs out
        if (seconds <= 30) {
            displayLabel.setForeground(new Color(220, 50, 50));   // Red — urgent
        } else if (seconds <= 60) {
            displayLabel.setForeground(new Color(230, 130, 0));   // Orange — warning
        } else {
            displayLabel.setForeground(new Color(30, 160, 100));  // Green — safe
        }
    }
}

package service;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 🔒 Anti-Cheat Monitoring Service
 *
 * Cheat prevention:
 *  1. Detects window minimize          → warning
 *  2. Detects focus loss / tab switch  → warning (with cooldown to avoid dialog false-positives)
 *  3. Blocks right-click context menu  → no copy-paste via mouse
 *  4. Blocks Ctrl+C / Ctrl+V / Ctrl+X  → no clipboard cheating
 *  5. Blocks Alt+Tab / Alt+F4 / Win key via KeyEventDispatcher
 *  6. Forces window to front on focus regain
 *  7. After MAX_WARNINGS → auto-submit
 */
public class MonitoringService {

    private boolean cameraOn = false;
    private boolean micOn    = false;

    private int warningCount = 0;
    private static final int MAX_WARNINGS = 3;

    // Cooldown: ignore focus-loss events for this many ms after a warning dialog
    private static final long WARNING_COOLDOWN_MS = 2500;
    private long lastWarningTime = 0;

    // Prevent re-entrant warning dialogs
    private boolean showingWarning = false;

    private final List<String> eventLog = new ArrayList<>();
    private JFrame  monitoredWindow;
    private Runnable onMaxWarningsCallback;

    private JLabel cameraLabel;
    private JLabel micLabel;
    private JLabel warningLabel;

    // KeyEventDispatcher to intercept system shortcuts
    private KeyEventDispatcher keyBlocker;

    public MonitoringService(JFrame window, Runnable onMaxWarnings) {
        this.monitoredWindow       = window;
        this.onMaxWarningsCallback = onMaxWarnings;
    }

    // ── Start / Stop ──────────────────────────────────────────────────────────

    public void startMonitoring() {
        cameraOn = true;
        micOn    = true;
        log("📷 Camera activated");
        log("🎤 Microphone activated");
        updateIndicators();
        attachWindowListeners();
        attachKeyBlocker();
        blockRightClick();
    }

    public void stopMonitoring() {
        cameraOn = false;
        micOn    = false;
        log("Monitoring stopped");
        updateIndicators();
        // Remove key blocker
        if (keyBlocker != null) {
            KeyboardFocusManager.getCurrentKeyboardFocusManager()
                .removeKeyEventDispatcher(keyBlocker);
        }
    }

    // ── Window listeners ──────────────────────────────────────────────────────

    private void attachWindowListeners() {

        // 1. Minimize detection
        monitoredWindow.addWindowListener(new WindowAdapter() {
            @Override
            public void windowIconified(WindowEvent e) {
                triggerWarning("Window minimized — restore window to continue");
                // Force restore
                SwingUtilities.invokeLater(() -> {
                    monitoredWindow.setState(JFrame.NORMAL);
                    monitoredWindow.toFront();
                    monitoredWindow.requestFocus();
                });
            }

            @Override
            public void windowDeactivated(WindowEvent e) {
                // Skip if we're showing a warning dialog (that dialog stole focus)
                if (showingWarning) return;
                // Skip during cooldown period
                long now = System.currentTimeMillis();
                if (now - lastWarningTime < WARNING_COOLDOWN_MS) return;
                triggerWarning("Focus lost — do not switch tabs or windows");
            }

            @Override
            public void windowActivated(WindowEvent e) {
                // Bring back to front whenever regaining focus
                monitoredWindow.toFront();
            }
        });
    }

    // ── Key blocker ───────────────────────────────────────────────────────────

    private void attachKeyBlocker() {
        keyBlocker = new KeyEventDispatcher() {
            @Override
            public boolean dispatchKeyEvent(KeyEvent e) {
                if (e.getID() != KeyEvent.KEY_PRESSED) return false;

                int    code = e.getKeyCode();
                int    mods = e.getModifiersEx();
                boolean ctrl = (mods & KeyEvent.CTRL_DOWN_MASK)  != 0;
                boolean alt  = (mods & KeyEvent.ALT_DOWN_MASK)   != 0;
                boolean win  = (mods & KeyEvent.META_DOWN_MASK)  != 0;

                // Block Ctrl+C, Ctrl+V, Ctrl+X (copy/paste/cut)
                if (ctrl && (code == KeyEvent.VK_C ||
                             code == KeyEvent.VK_V ||
                             code == KeyEvent.VK_X)) {
                    log("Blocked clipboard shortcut: Ctrl+" + KeyEvent.getKeyText(code));
                    e.consume();
                    return true;
                }

                // Block Alt+Tab (switch window)
                if (alt && code == KeyEvent.VK_TAB) {
                    log("Blocked Alt+Tab");
                    triggerWarning("Alt+Tab detected — do not switch windows");
                    e.consume();
                    return true;
                }

                // Block Alt+F4 (close window)
                if (alt && code == KeyEvent.VK_F4) {
                    log("Blocked Alt+F4");
                    e.consume();
                    return true;
                }

                // Block Windows key
                if (win) {
                    log("Blocked Win key");
                    e.consume();
                    return true;
                }

                // Block F11 / F12 (browser full-screen / DevTools tricks)
                if (code == KeyEvent.VK_F11 || code == KeyEvent.VK_F12) {
                    log("Blocked F11/F12");
                    e.consume();
                    return true;
                }

                return false;
            }
        };
        KeyboardFocusManager.getCurrentKeyboardFocusManager()
            .addKeyEventDispatcher(keyBlocker);
    }

    // ── Right-click blocker ───────────────────────────────────────────────────

    private void blockRightClick() {
        // Add a glass pane that consumes right-click events
        JPanel glass = new JPanel(null) {
            @Override protected void paintComponent(Graphics g) { /* transparent */ }
        };
        glass.setOpaque(false);
        glass.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e)) {
                    log("Blocked right-click");
                    e.consume();
                }
            }
        });
        // Pass through left-clicks to underlying components
        glass.addMouseMotionListener(new MouseMotionAdapter() {});
        monitoredWindow.setGlassPane(glass);
        glass.setVisible(true);
    }

    // ── Warning logic ─────────────────────────────────────────────────────────

    private void triggerWarning(String reason) {
        if (showingWarning) return; // prevent re-entrance
        long now = System.currentTimeMillis();
        if (now - lastWarningTime < WARNING_COOLDOWN_MS) return; // cooldown

        warningCount++;
        lastWarningTime = now;
        String msg = "⚠️ Warning " + warningCount + "/" + MAX_WARNINGS + ": " + reason;
        log(msg);
        updateWarningLabel();

        if (warningCount >= MAX_WARNINGS) {
            log("❌ Max warnings — quiz auto-submitted.");
            showingWarning = true;
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(monitoredWindow,
                    "Maximum warnings reached!\nYour quiz is being auto-submitted.",
                    "⚠️ Proctoring Alert", JOptionPane.ERROR_MESSAGE);
                showingWarning = false;
                if (onMaxWarningsCallback != null) onMaxWarningsCallback.run();
            });
        } else {
            showingWarning = true;
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(monitoredWindow,
                    msg + "\n\nPlease stay in the quiz window.\n" +
                    "You have " + (MAX_WARNINGS - warningCount) + " warning(s) remaining.",
                    "⚠️ Proctoring Warning", JOptionPane.WARNING_MESSAGE);
                showingWarning = false;
                lastWarningTime = System.currentTimeMillis(); // reset after dialog closes
                monitoredWindow.toFront();
                monitoredWindow.requestFocus();
            });
        }
    }

    // ── Status panel ──────────────────────────────────────────────────────────

    public JPanel createStatusPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        panel.setBackground(new Color(25, 25, 35));
        panel.setBorder(BorderFactory.createLineBorder(new Color(60, 60, 80), 1));

        cameraLabel  = badge("📷 Camera OFF", false);
        micLabel     = badge("🎤  Mic OFF",    false);
        warningLabel = badge("🛡 0 Warnings",  true);

        panel.add(cameraLabel);
        panel.add(micLabel);
        panel.add(warningLabel);
        return panel;
    }

    private JLabel badge(String text, boolean neutral) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("SansSerif", Font.BOLD, 12));
        l.setOpaque(true);
        l.setBorder(BorderFactory.createEmptyBorder(3, 8, 3, 8));
        l.setBackground(neutral ? new Color(60, 60, 80) : new Color(150, 40, 40));
        l.setForeground(Color.WHITE);
        return l;
    }

    private void updateIndicators() {
        if (cameraLabel == null) return;
        SwingUtilities.invokeLater(() -> {
            cameraLabel.setText(cameraOn ? "📷 Camera ON"  : "📷 Camera OFF");
            cameraLabel.setBackground(cameraOn ? new Color(30, 140, 80) : new Color(150, 40, 40));
            micLabel.setText(micOn ? "🎤  Mic ON" : "🎤  Mic OFF");
            micLabel.setBackground(micOn ? new Color(30, 140, 80) : new Color(150, 40, 40));
        });
    }

    private void updateWarningLabel() {
        if (warningLabel == null) return;
        SwingUtilities.invokeLater(() -> {
            warningLabel.setText("⚠️ " + warningCount + "/" + MAX_WARNINGS + " Warnings");
            warningLabel.setBackground(warningCount >= MAX_WARNINGS
                ? new Color(180, 30, 30) : new Color(200, 120, 0));
        });
    }

    // ── Logging ───────────────────────────────────────────────────────────────

    private void log(String event) {
        String entry = "[" + java.time.LocalTime.now()
            .format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss"))
            + "] " + event;
        eventLog.add(entry);
        System.out.println("[PROCTOR] " + entry);
    }

    public List<String> getEventLog()  { return new ArrayList<>(eventLog); }
    public int          getWarningCount() { return warningCount; }
    public boolean      isCameraOn()   { return cameraOn; }
    public boolean      isMicOn()      { return micOn; }
}

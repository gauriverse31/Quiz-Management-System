package service;

import model.Question;
import java.util.*;

/**
 * 🤖 Question Suggestion Engine
 * FIXED: Topic filter now strictly matches — selecting "Maths" shows ONLY Maths questions.
 * FIXED: Added Maths template questions.
 * FIXED: No more leaking Java/OS questions when a specific subject is chosen.
 */
public class QuestionSuggestion {

    private final DataStore dataStore;

    private static final Map<String, List<Question>> TEMPLATES = new LinkedHashMap<>();

    static {
        // ── Java ──────────────────────────────────────────────────────────────
        add("Java", "EASY",
            new Question("What is the size of int in Java?",
                new String[]{"8 bytes","4 bytes","2 bytes","16 bytes"}, 1,
                Question.Difficulty.EASY, "Java"),
            new Question("Which of these is NOT a primitive type?",
                new String[]{"int","float","String","char"}, 2,
                Question.Difficulty.EASY, "Java")
        );
        add("Java", "MEDIUM",
            new Question("What does 'super' keyword do?",
                new String[]{"Creates new object","Refers to parent class","Makes class final","Overloads method"}, 1,
                Question.Difficulty.MEDIUM, "Java"),
            new Question("Which collection does NOT allow duplicates?",
                new String[]{"ArrayList","LinkedList","HashSet","Stack"}, 2,
                Question.Difficulty.MEDIUM, "Java")
        );
        add("Java", "HARD",
            new Question("What is a ClassLoader?",
                new String[]{"Loads .class files at runtime","Compiles Java code","Manages memory","None"}, 0,
                Question.Difficulty.HARD, "Java")
        );

        // ── Data Structures ───────────────────────────────────────────────────
        add("Data Structures", "EASY",
            new Question("Array index starts at?",
                new String[]{"1","0","-1","Depends"}, 1,
                Question.Difficulty.EASY, "Data Structures")
        );
        add("Data Structures", "MEDIUM",
            new Question("Which traversal gives sorted output in BST?",
                new String[]{"Preorder","Postorder","Inorder","Level order"}, 2,
                Question.Difficulty.MEDIUM, "Data Structures")
        );
        add("Data Structures", "HARD",
            new Question("What is the space complexity of DFS?",
                new String[]{"O(1)","O(V)","O(V+E)","O(E)"}, 1,
                Question.Difficulty.HARD, "Data Structures")
        );

        // ── Networks ──────────────────────────────────────────────────────────
        add("Networks", "EASY",
            new Question("What does HTTP stand for?",
                new String[]{"HyperText Transfer Protocol","High Tech Transfer","None","Host Transfer"}, 0,
                Question.Difficulty.EASY, "Networks")
        );

        // ── Operating Systems ─────────────────────────────────────────────────
        add("Operating Systems", "EASY",
            new Question("What is a process?",
                new String[]{"A program in execution","A file","A thread","None"}, 0,
                Question.Difficulty.EASY, "Operating Systems")
        );
        add("Operating Systems", "MEDIUM",
            new Question("What is virtual memory?",
                new String[]{"Extra RAM","Disk used as RAM","Cache memory","ROM"}, 1,
                Question.Difficulty.MEDIUM, "Operating Systems")
        );

        // ── Maths ─────────────────────────────────────────────────────────────
        add("Maths", "EASY",
            new Question("What is the value of π (pi) approximately?",
                new String[]{"3.14","2.71","1.41","1.73"}, 0,
                Question.Difficulty.EASY, "Maths"),
            new Question("What is 12 × 12?",
                new String[]{"124","144","132","148"}, 1,
                Question.Difficulty.EASY, "Maths"),
            new Question("What is the square root of 144?",
                new String[]{"11","12","13","14"}, 1,
                Question.Difficulty.EASY, "Maths")
        );
        add("Maths", "MEDIUM",
            new Question("What is the derivative of x² ?",
                new String[]{"x","2x","x²","2"}, 1,
                Question.Difficulty.MEDIUM, "Maths"),
            new Question("What is the sum of angles in a triangle?",
                new String[]{"90°","180°","270°","360°"}, 1,
                Question.Difficulty.MEDIUM, "Maths"),
            new Question("What is log₁₀(1000)?",
                new String[]{"2","3","4","10"}, 1,
                Question.Difficulty.MEDIUM, "Maths")
        );
        add("Maths", "HARD",
            new Question("What is the integral of sin(x)?",
                new String[]{"cos(x)","−cos(x)","sin(x)","−sin(x)"}, 1,
                Question.Difficulty.HARD, "Maths"),
            new Question("What is the determinant of the identity matrix of order 2?",
                new String[]{"0","2","1","−1"}, 2,
                Question.Difficulty.HARD, "Maths")
        );

        // ── Physics ───────────────────────────────────────────────────────────
        add("Physics", "EASY",
            new Question("What is the unit of force?",
                new String[]{"Watt","Joule","Newton","Pascal"}, 2,
                Question.Difficulty.EASY, "Physics"),
            new Question("Speed of light is approximately?",
                new String[]{"3×10⁶ m/s","3×10⁸ m/s","3×10¹⁰ m/s","3×10⁴ m/s"}, 1,
                Question.Difficulty.EASY, "Physics")
        );
        add("Physics", "MEDIUM",
            new Question("What is Newton's second law?",
                new String[]{"F=mv","F=ma","F=m/a","F=a/m"}, 1,
                Question.Difficulty.MEDIUM, "Physics")
        );
    }

    /** Helper to add questions grouped by topic+difficulty key */
    private static void add(String topic, String diff, Question... qs) {
        String key = topic + "_" + diff;
        TEMPLATES.computeIfAbsent(key, k -> new ArrayList<>());
        for (Question q : qs) TEMPLATES.get(key).add(q);
    }

    public QuestionSuggestion() {
        this.dataStore = DataStore.getInstance();
    }

    /**
     * Returns up to maxResults suggested questions.
     * FIXED: Topic filter is strict — only matching topic questions returned.
     *
     * @param difficulty null = any
     * @param topic      null = any; "Maths" = only Maths questions
     * @param maxResults max count to return
     */
    public List<Question> suggest(Question.Difficulty difficulty, String topic, int maxResults) {
        // Step 1: from existing bank (strict topic match)
        List<Question> fromBank = dataStore.filterQuestions(difficulty, topic);
        List<Question> result   = new ArrayList<>(fromBank);

        // Step 2: fill from templates if needed (strict topic match)
        if (result.size() < maxResults) {
            List<Question> templatePool = getTemplates(difficulty, topic);
            for (Question t : templatePool) {
                if (result.size() >= maxResults) break;
                if (!isDuplicate(t, result)) result.add(t);
            }
        }

        Collections.shuffle(result);
        return result.subList(0, Math.min(result.size(), maxResults));
    }

    /**
     * FIXED: Topic matching is case-insensitive exact match (not startsWith).
     * "Maths" will NOT match "Mathematics" or "Java".
     */
    private List<Question> getTemplates(Question.Difficulty difficulty, String topic) {
        List<Question> pool = new ArrayList<>();
        for (Map.Entry<String, List<Question>> entry : TEMPLATES.entrySet()) {
            String key = entry.getKey(); // e.g. "Maths_EASY"

            // FIXED: exact topic match (case-insensitive), not prefix match
            boolean topicMatch = (topic == null || topic.isBlank())
                || key.toLowerCase().startsWith(topic.toLowerCase() + "_");

            boolean diffMatch = (difficulty == null)
                || key.endsWith("_" + difficulty.name());

            if (topicMatch && diffMatch) pool.addAll(entry.getValue());
        }
        return pool;
    }

    private boolean isDuplicate(Question candidate, List<Question> existing) {
        for (Question q : existing)
            if (q.getQuestionText().equalsIgnoreCase(candidate.getQuestionText()))
                return true;
        return false;
    }

    /** Returns all known topics (from bank + all template topics). */
    public List<String> getAllTopics() {
        Set<String> topics = new LinkedHashSet<>(dataStore.getAllTopics());
        for (String key : TEMPLATES.keySet()) {
            String t = key.substring(0, key.lastIndexOf('_'));
            topics.add(t);
        }
        return new ArrayList<>(topics);
    }
}

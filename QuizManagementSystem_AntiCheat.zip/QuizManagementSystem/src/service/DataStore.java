package service;

import model.*;
import java.io.*;
import java.util.*;

/**
 * Singleton service that manages all persistent data:
 * - Questions bank
 * - Registered users
 * - Quiz results / leaderboard
 *
 * Uses Java Object Serialization for file-based storage.
 * Demonstrates ENCAPSULATION and Singleton pattern.
 */
public class DataStore {

    // ── Singleton setup ───────────────────────────────────────────────────────
    private static DataStore instance;
    private DataStore() { loadAll(); }
    public static DataStore getInstance() {
        if (instance == null) instance = new DataStore();
        return instance;
    }

    // ── File paths ────────────────────────────────────────────────────────────
    private static final String QUESTIONS_FILE = "data/questions.dat";
    private static final String USERS_FILE     = "data/users.dat";
    private static final String RESULTS_FILE   = "data/results.dat";

    // ── In-memory data ────────────────────────────────────────────────────────
    private List<Question>   questions = new ArrayList<>();
    private List<User>       users     = new ArrayList<>();
    private List<QuizResult> results   = new ArrayList<>();

    // ── Initialization ────────────────────────────────────────────────────────

    /** Loads all data from files; seeds defaults if files don't exist. */
    private void loadAll() {
        new File("data").mkdirs(); // ensure data directory exists
        questions = loadList(QUESTIONS_FILE);
        users     = loadList(USERS_FILE);
        results   = loadList(RESULTS_FILE);

        if (users.isEmpty())     seedDefaultUsers();
        if (questions.isEmpty()) seedDefaultQuestions();
    }

    private void seedDefaultUsers() {
        users.add(new Teacher("Prof. Sharma", "teacher1", "pass123"));
        users.add(new Student("Amit Kumar",   "student1", "pass123"));
        users.add(new Student("Priya Singh",  "student2", "pass123"));
        saveUsers();
    }

    private void seedDefaultQuestions() {
        // Java questions
        addQuestion(new Question("What is JVM?",
            new String[]{"Java Virtual Machine","Java Visual Mode","Java Verified Module","None"},
            0, Question.Difficulty.EASY, "Java"));
        addQuestion(new Question("Which keyword is used for inheritance in Java?",
            new String[]{"implements","extends","inherits","super"},
            1, Question.Difficulty.EASY, "Java"));
        addQuestion(new Question("What is the default value of an int in Java?",
            new String[]{"null","1","0","-1"},
            2, Question.Difficulty.EASY, "Java"));
        addQuestion(new Question("Which of the following is NOT a Java OOP principle?",
            new String[]{"Encapsulation","Polymorphism","Compilation","Abstraction"},
            2, Question.Difficulty.MEDIUM, "Java"));
        addQuestion(new Question("What does 'final' keyword do to a class?",
            new String[]{"Makes it abstract","Prevents inheritance","Makes it static","None"},
            1, Question.Difficulty.MEDIUM, "Java"));
        addQuestion(new Question("What is method overloading?",
            new String[]{"Same name, different return type","Same name, different parameters","Different name, same parameters","None"},
            1, Question.Difficulty.MEDIUM, "Java"));
        addQuestion(new Question("Which interface must be implemented for multithreading via lambda?",
            new String[]{"Serializable","Runnable","Callable","Comparable"},
            1, Question.Difficulty.HARD, "Java"));
        addQuestion(new Question("What is the time complexity of HashMap get()?",
            new String[]{"O(n)","O(log n)","O(1)","O(n²)"},
            2, Question.Difficulty.HARD, "Java"));

        // Data Structures questions
        addQuestion(new Question("Which data structure uses LIFO?",
            new String[]{"Queue","Stack","LinkedList","Tree"},
            1, Question.Difficulty.EASY, "Data Structures"));
        addQuestion(new Question("What is the height of a balanced BST with n nodes?",
            new String[]{"O(n)","O(log n)","O(1)","O(n log n)"},
            1, Question.Difficulty.MEDIUM, "Data Structures"));
        addQuestion(new Question("Which sorting algorithm has worst-case O(n log n)?",
            new String[]{"Bubble Sort","Quick Sort","Merge Sort","Selection Sort"},
            2, Question.Difficulty.HARD, "Data Structures"));

        // OS questions
        addQuestion(new Question("What is a deadlock?",
            new String[]{"A crash","Circular wait for resources","Memory overflow","None"},
            1, Question.Difficulty.EASY, "Operating Systems"));
        addQuestion(new Question("Which scheduling algorithm has minimum average waiting time?",
            new String[]{"FCFS","SJF","Round Robin","Priority"},
            1, Question.Difficulty.MEDIUM, "Operating Systems"));

        saveQuestions();
    }

    // ── Questions API ─────────────────────────────────────────────────────────

    public List<Question> getQuestions() { return new ArrayList<>(questions); }

    public void addQuestion(Question q) {
        questions.add(q);
        saveQuestions();
    }

    public void removeQuestion(int index) {
        if (index >= 0 && index < questions.size()) {
            questions.remove(index);
            saveQuestions();
        }
    }

    /** Filters questions by difficulty and/or topic. Null = no filter. */
    public List<Question> filterQuestions(Question.Difficulty difficulty, String topic) {
        List<Question> filtered = new ArrayList<>();
        for (Question q : questions) {
            boolean diffMatch  = (difficulty == null || q.getDifficulty() == difficulty);
            boolean topicMatch = (topic == null || topic.isBlank()
                                  || q.getTopic().equalsIgnoreCase(topic));
            if (diffMatch && topicMatch) filtered.add(q);
        }
        return filtered;
    }

    /** Returns a list of all unique topics in the question bank. */
    public List<String> getAllTopics() {
        Set<String> topics = new LinkedHashSet<>();
        for (Question q : questions) topics.add(q.getTopic());
        return new ArrayList<>(topics);
    }

    // ── Users API ─────────────────────────────────────────────────────────────

    public List<User> getUsers() { return new ArrayList<>(users); }

    public void addUser(User u) {
        users.add(u);
        saveUsers();
    }

    /** Returns a User by username+password, or null if not found. */
    public User authenticate(String username, String password) {
        for (User u : users) {
            if (u.getUsername().equals(username) && u.getPassword().equals(password))
                return u;
        }
        return null;
    }

    // ── Results API ───────────────────────────────────────────────────────────

    public List<QuizResult> getResults() { return new ArrayList<>(results); }

    public void addResult(QuizResult r) {
        results.add(r);
        saveResults();
    }

    /** Returns results sorted by score desc, then time asc. */
    public List<QuizResult> getLeaderboard() {
        List<QuizResult> sorted = new ArrayList<>(results);
        Collections.sort(sorted);
        return sorted;
    }

    /** Returns statistics: [highest, average, total count] */
    public double[] getStats() {
        if (results.isEmpty()) return new double[]{0, 0, 0};
        double highest = 0, sum = 0;
        for (QuizResult r : results) {
            if (r.getPercentage() > highest) highest = r.getPercentage();
            sum += r.getPercentage();
        }
        return new double[]{highest, sum / results.size(), results.size()};
    }

    // ── Persistence helpers ───────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    private <T> List<T> loadList(String path) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(path))) {
            return (List<T>) ois.readObject();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    private <T> void saveList(String path, List<T> list) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path))) {
            oos.writeObject(list);
        } catch (IOException e) {
            System.err.println("Save error for " + path + ": " + e.getMessage());
        }
    }

    public void saveQuestions() { saveList(QUESTIONS_FILE, questions); }
    public void saveUsers()     { saveList(USERS_FILE, users); }
    public void saveResults()   { saveList(RESULTS_FILE, results); }
}

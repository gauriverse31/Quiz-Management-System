import ui.LoginScreen;

import javax.swing.*;

/**
 * 🚀 QuizPro — Main entry point.
 *
 * Run this class to launch the application.
 * The system is pre-seeded with sample users and questions on first run.
 *
 * Default credentials:
 *   Teacher  → username: teacher1  password: pass123
 *   Student  → username: student1  password: pass123
 *   Student  → username: student2  password: pass123
 */
public class Main {
    public static void main(String[] args) {
        // Run on the Swing Event Dispatch Thread (EDT) — best practice
        SwingUtilities.invokeLater(() -> {
            // Use system look-and-feel as base (we style on top of it)
            try {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            } catch (Exception e) {
                System.err.println("LAF setup failed: " + e.getMessage());
            }

            // Launch login screen
            new LoginScreen().setVisible(true);
        });
    }
}
